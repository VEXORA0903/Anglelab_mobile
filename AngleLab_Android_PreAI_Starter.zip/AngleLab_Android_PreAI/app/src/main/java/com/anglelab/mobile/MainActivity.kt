package com.anglelab.mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        val title = TextView(this).apply {
            text = "AngleLab Mobile"
            textSize = 28f
            setTextColor(0xFF111827.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Pre-AI transparent overlay prototype\\nManual geometry • single cushion • path switching"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 28)
        }
        val start = Button(this).apply {
            text = "Start transparent overlay"
            setOnClickListener { startOverlay() }
        }
        val stop = Button(this).apply {
            text = "Stop overlay"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                Toast.makeText(this@MainActivity, "AngleLab overlay stopped", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "Grant 'Display over other apps' permission when Android asks. The overlay drawing is click-through; use the floating control strip to change paths, power and size."
            textSize = 13f
            setPadding(0, 24, 0, 0)
        }
        root.addView(title, ViewGroup.LayoutParams(-1, -2))
        root.addView(subtitle, ViewGroup.LayoutParams(-1, -2))
        root.addView(start, ViewGroup.LayoutParams(-1, -2))
        root.addView(stop, ViewGroup.LayoutParams(-1, -2))
        root.addView(note, ViewGroup.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Enable AngleLab in the permission screen, then return and tap Start.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "AngleLab overlay started", Toast.LENGTH_SHORT).show()
        finish()
    }
}
