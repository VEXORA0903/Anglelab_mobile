package com.anglelab.mobile

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var drawing: AngleOverlayView? = null
    private var controls: LinearLayout? = null
    private var pathIndex = 0
    private var powerIndex = 0
    private var scale = 1.0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (drawing != null) return START_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        drawing = AngleOverlayView(this).also { view ->
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.START
            wm.addView(view, p)
        }
        addControlPanel()
        return START_STICKY
    }

    private fun addControlPanel() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 8)
            setBackgroundColor(0xDD151923.toInt())
        }
        val title = TextView(this).apply {
            text = "ANGLELAB  ⋮"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val path = Button(this).apply {
            text = "Path: ${pathLabel()}"
            setOnClickListener {
                pathIndex = (pathIndex + 1) % 2
                text = "Path: ${pathLabel()}"
                drawing?.setMode(pathIndex, powerIndex, scale)
            }
        }
        val power = Button(this).apply {
            text = "Power: ${powerLabel()}"
            setOnClickListener {
                powerIndex = (powerIndex + 1) % 3
                text = "Power: ${powerLabel()}"
                drawing?.setMode(pathIndex, powerIndex, scale)
            }
        }
        val resize = Button(this).apply {
            text = "Size +"
            setOnClickListener {
                scale = (scale + 0.1f).coerceAtMost(1.8f)
                drawing?.setMode(pathIndex, powerIndex, scale)
            }
        }
        val shrink = Button(this).apply {
            text = "Size −"
            setOnClickListener {
                scale = (scale - 0.1f).coerceAtLeast(0.5f)
                drawing?.setMode(pathIndex, powerIndex, scale)
            }
        }
        val close = Button(this).apply {
            text = "× Close"
            setOnClickListener { stopSelf() }
        }
        listOf(title, path, power, resize, shrink, close).forEach {
            panel.addView(it, LinearLayout.LayoutParams(160, 42))
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12
            y = 120
        }
        wm.addView(panel, params)
        controls = panel

        // Drag the panel by touching and moving on its title strip.
        title.setOnTouchListener(object : android.view.View.OnTouchListener {
            var startX = 0
            var startY = 0
            var downX = 0f
            var downY = 0f
            override fun onTouch(v: android.view.View, e: android.view.MotionEvent): Boolean {
                when (e.action) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        downX = e.rawX; downY = e.rawY
                        return true
                    }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        params.x = startX - (e.rawX - downX).toInt()
                        params.y = startY + (e.rawY - downY).toInt()
                        wm.updateViewLayout(panel, params)
                        return true
                    }
                }
                return true
            }
        })
    }

    private fun pathLabel() = if (pathIndex == 0) "Direct" else "1 Cushion"
    private fun powerLabel() = listOf("100%", "75%", "50%")[powerIndex]

    override fun onDestroy() {
        drawing?.let { runCatching { wm.removeView(it) } }
        controls?.let { runCatching { wm.removeView(it) } }
        drawing = null
        controls = null
        super.onDestroy()
    }
}
