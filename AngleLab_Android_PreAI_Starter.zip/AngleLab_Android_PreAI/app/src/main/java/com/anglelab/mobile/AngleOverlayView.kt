package com.anglelab.mobile

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Color
import android.view.View
import kotlin.math.min

/**
 * Transparent, click-through drawing layer.
 * This is a mobile starter renderer; replace the demo coordinates and path
 * calculation with the calibrated original AngleLab v1.2.x engine.
 */
class AngleOverlayView(context: Context) : View(context) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.2f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var pathMode = 0
    private var powerMode = 0
    private var scaleFactor = 1f

    fun setMode(path: Int, power: Int, scale: Float) {
        pathMode = path
        powerMode = power
        scaleFactor = scale
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        // Demo table region; original project table calibration will replace this.
        val tableW = min(w * 0.78f, h * 1.45f) * scaleFactor
        val tableH = tableW * 0.52f
        val left = (w - tableW) / 2f
        val top = (h - tableH) / 2f
        val right = left + tableW
        val bottom = top + tableH

        // Subtle 12% black backing behind geometry, not an opaque screen.
        fill.color = 0x1F000000
        canvas.drawRoundRect(left, top, right, bottom, 12f, 12f, fill)

        line.color = 0xCCFFFFFF.toInt()
        line.strokeWidth = 2f
        canvas.drawRoundRect(left, top, right, bottom, 12f, 12f, line)

        val cueX = left + tableW * 0.22f
        val cueY = top + tableH * 0.66f
        val targetX = left + tableW * 0.70f
        val targetY = top + tableH * 0.34f
        val radius = tableH * 0.035f

        // Guide line and ball markers.
        line.color = 0xCCFFFFFF.toInt()
        line.strokeWidth = 2.4f
        canvas.drawLine(cueX, cueY, targetX, targetY, line)

        fill.color = 0xFFFFFFFF.toInt()
        canvas.drawCircle(cueX, cueY, radius, fill)
        fill.color = 0xFFE53935.toInt()
        canvas.drawCircle(targetX, targetY, radius, fill)

        val route = Path().apply {
            moveTo(cueX, cueY)
            if (pathMode == 0) {
                lineTo(targetX, targetY)
            } else {
                val bounceX = left + tableW * (if (powerMode == 0) 0.88f else 0.82f)
                val bounceY = top + tableH * (if (powerMode == 2) 0.62f else 0.12f)
                lineTo(bounceX, bounceY)
                lineTo(targetX, targetY)
            }
        }
        line.color = if (pathMode == 0) 0xFFFF5252.toInt() else 0xFF42A5F5.toInt()
        line.strokeWidth = 4f
        canvas.drawPath(route, line)

        // Direction indicator.
        fill.color = 0xFFFFFFFF.toInt()
        canvas.drawCircle(targetX, targetY, radius * 0.32f, fill)
    }
}
