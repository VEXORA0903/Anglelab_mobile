# AngleLab Android — Pre-AI starter

This is an Android Studio starter project for a transparent, floating AngleLab overlay.

## Included
- Android overlay permission flow
- Transparent, click-through drawing layer
- Movable floating control panel
- Direct / one-cushion path toggle
- 100%, 75%, 50% power selector
- Overlay size controls
- Lightweight 12%-opacity black table backing

## Important project status
This is a working UI/overlay prototype, **not yet a port of the original calibrated AngleLab engine**.
The current drawing uses demonstration coordinates. The original v1.2.x calculation source was not present in the current working files when this starter was generated, so its exact path geometry, manual ball-placement behavior, and calibrated cushion math still need to be merged.

The project deliberately excludes AI tracking and multi-cushion routing. It uses a single cushion route only.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android phone.
5. Open AngleLab Mobile, grant "Display over other apps", then start the overlay.

## Android behavior
Android requires explicit user permission for drawing over other apps. The overlay drawing surface is click-through so the game remains touchable; use the floating control panel to switch paths, power and size.

## Next integration step
Import the original pre-AI AngleLab v1.2.x source and replace the demo coordinates/path construction in `AngleOverlayView.kt` with the existing geometry and trajectory engine. Keep the one-cushion-only constraint.

## Build an APK using only your phone (GitHub Actions)
1. Extract this ZIP on your phone.
2. Create a new **public or private** GitHub repository in the GitHub app/browser.
3. Upload the extracted project files and folders to the repository. Preserve the folder structure, including `.github/workflows/build-apk.yml` (if the file manager hides `.github`, create that folder and workflow file in GitHub using **Add file > Create new file** and the path `.github/workflows/build-apk.yml`).
4. Open the repository's **Actions** tab and select **Build AngleLab Android APK**. Tap **Run workflow** if it has not started automatically after upload.
5. When the run finishes successfully, open the run and download the **AngleLab-debug-APK** artifact. Extract the downloaded artifact ZIP; inside is `app-debug.apk`.
6. Tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/files app; enable it only for the app you used, then install.

This produces a debug/test APK, not a Play Store release. The prototype uses demo geometry until the original AngleLab calculation source is integrated.
